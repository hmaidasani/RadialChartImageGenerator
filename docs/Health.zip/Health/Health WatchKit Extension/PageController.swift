//
//  PageController.swift
//  Health
//
//  Created by Maidasani, Hitesh on 2/7/15.
//  Copyright (c) 2015 Intuit. All rights reserved.
//

import WatchKit
import Foundation


class PageController: WKInterfaceController {
    let duration = 0.5
    @IBOutlet weak var outerGroup: WKInterfaceGroup!
    @IBOutlet weak var middleGroup: WKInterfaceGroup!
    @IBOutlet weak var innerGroup: WKInterfaceGroup!
    @IBOutlet weak var valLabel: WKInterfaceLabel!
    @IBOutlet weak var ofLabel: WKInterfaceLabel!
    @IBOutlet weak var maxLabel: WKInterfaceLabel!
    @IBOutlet weak var unitLabel: WKInterfaceLabel!
    @IBOutlet weak var arcLabels: WKInterfaceImage!
    @IBOutlet weak var arcLabelsGroup: WKInterfaceGroup!
    @IBOutlet weak var outerIcon: WKInterfaceImage!
    @IBOutlet weak var outerIconGroup: WKInterfaceGroup!
    
    var animated = false
    var pagetitle = ""
    var arcs = 0
    var arcOuter = ""
    var arcMiddle = ""
    var arcInner = ""
    var arcOuterVal = 1.0
    var arcOuterMax = 1.0
    var arcMiddleVal = 1.0
    var arcMiddleMax = 1.0
    var arcInnerVal = 1.0
    var arcInnerMax = 1.0
    var units = ""
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        animated = false
        pagetitle = context?.valueForKey("title") as String
        self.setTitle(pagetitle)

        arcs = context?.valueForKey("arcs") as Int
        arcOuter = context?.valueForKey("arcOuter") as String
        arcMiddle = context?.valueForKey("arcMiddle") as String
        arcInner = context?.valueForKey("arcInner") as String
        arcOuterVal = context?.valueForKey("arcOuterVal") as Double
        arcOuterMax = context?.valueForKey("arcOuterMax") as Double
        arcMiddleVal = context?.valueForKey("arcMiddleVal") as Double
        arcMiddleMax = context?.valueForKey("arcMiddleMax") as Double
        arcInnerVal = context?.valueForKey("arcInnerVal") as Double
        arcInnerMax = context?.valueForKey("arcInnerMax") as Double
        units = context?.valueForKey("units") as String
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        if(!animated){
            if(arcs == 3){
                arcLabels.setImageNamed("arcLabels")
                outerIcon.setHidden(true)
                outerIconGroup.setHidden(true)
                outerGroup.setBackgroundImageNamed(arcOuter)
                middleGroup.setBackgroundImageNamed(arcMiddle)
                innerGroup.setBackgroundImageNamed(arcInner)
                outerGroup.startAnimatingWithImagesInRange(NSMakeRange(0, Int(arcOuterVal/arcOuterMax*100)+1), duration: duration, repeatCount: 1)
                middleGroup.startAnimatingWithImagesInRange(NSMakeRange(0, Int(arcMiddleVal/arcMiddleMax*100)+1), duration: duration, repeatCount: 1)
                innerGroup.startAnimatingWithImagesInRange(NSMakeRange(0, Int(arcInnerVal/arcInnerMax*100)+1), duration: duration, repeatCount: 1)
                arcLabels.startAnimatingWithImagesInRange(NSMakeRange(0, 22), duration: 1.5, repeatCount: 1)
                animated = true
            } else if (arcs == 2) {
                outerGroup.setBackgroundImageNamed(arcOuter)
                middleGroup.setBackgroundImageNamed("")
                innerGroup.setBackgroundImageNamed(arcInner)
                outerGroup.startAnimatingWithImagesInRange(NSMakeRange(0, Int(arcOuterVal/arcOuterMax*100)+1), duration: duration, repeatCount: 1)
                innerGroup.startAnimatingWithImagesInRange(NSMakeRange(0, Int(arcInnerVal/arcInnerMax*100)+1), duration: duration, repeatCount: 1)
                animated = true
            } else if (arcs == 1) {
                arcLabels.setHidden(true)
                arcLabelsGroup.setHidden(true)
                outerIcon.setImageNamed(pagetitle.lowercaseString+".png")
                outerGroup.setBackgroundImageNamed(arcOuter)
                middleGroup.setBackgroundImageNamed("")
                innerGroup.setBackgroundImageNamed("")
                outerGroup.startAnimatingWithImagesInRange(NSMakeRange(0, Int(arcOuterVal/arcOuterMax*100)+1), duration: duration, repeatCount: 1)
                valLabel.setText(String(format:"%.0f", arcOuterVal))
                ofLabel.setText("OF")
                maxLabel.setText(String(format:"%.0f", arcOuterMax))
                unitLabel.setText(units)
                animated = true
            }
        }
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
