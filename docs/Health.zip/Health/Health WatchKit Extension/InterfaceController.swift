//
//  InterfaceController.swift
//  Health WatchKit Extension
//
//  Created by Maidasani, Hitesh on 2/7/15.
//  Copyright (c) 2015 Intuit. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func showPages() {
        var pages = ["activityPage", "activityPage", "activityPage", "activityPage"]
        var pageObjects:  [AnyObject] = []
        pageObjects.append([
        "title":"Activity", "arcs":3, "arcOuter":"outer", "arcMiddle":"middle", "arcInner":"inner", "arcOuterVal":312, "arcOuterMax":600, "arcMiddleVal":14, "arcMiddleMax":30, "arcInnerVal":40, "arcInnerMax":100, "units": ""
        ])
        pageObjects.append([
        "title":"Move", "arcs":1, "arcOuter":"outer", "arcMiddle":"middle", "arcInner":"inner", "arcOuterVal":312, "arcOuterMax":600, "arcMiddleVal":50, "arcMiddleMax":100, "arcInnerVal":50, "arcInnerMax":100, "units": "CALS"
        ])
        pageObjects.append([
        "title":"Exercise", "arcs":1, "arcOuter":"green", "arcMiddle":"middle", "arcInner":"inner", "arcOuterVal":14, "arcOuterMax":30, "arcMiddleVal":50, "arcMiddleMax":100, "arcInnerVal":50, "arcInnerMax":100, "units": "MINS"
        ])
        pageObjects.append([
        "title":"Stand", "arcs":1, "arcOuter":"blue", "arcMiddle":"middle", "arcInner":"inner", "arcOuterVal":3, "arcOuterMax":12, "arcMiddleVal":50, "arcMiddleMax":100, "arcInnerVal":50, "arcInnerMax":100, "units": "HRS"
        ])
        
        self.presentControllerWithNames(pages, contexts: pageObjects)
    }
    
}
