//
//  StandController.swift
//  Health
//
//  Created by Maidasani, Hitesh on 3/25/15.
//  Copyright (c) 2015 Intuit. All rights reserved.
//

import WatchKit
import Foundation


class StandController: WKInterfaceController {
    let duration = 0.5
    @IBOutlet weak var outerGroup: WKInterfaceGroup!
    @IBOutlet weak var middleGroup: WKInterfaceGroup!
    @IBOutlet weak var innerGroup: WKInterfaceGroup!
    @IBOutlet weak var valLabel: WKInterfaceLabel!
    @IBOutlet weak var ofLabel: WKInterfaceLabel!
    @IBOutlet weak var maxLabel: WKInterfaceLabel!
    @IBOutlet weak var unitLabel: WKInterfaceLabel!
    @IBOutlet weak var arcLabels: WKInterfaceImage!
    @IBOutlet weak var arcLabelsGroup: WKInterfaceGroup!
    @IBOutlet weak var outerIcon: WKInterfaceImage!
    @IBOutlet weak var outerIconGroup: WKInterfaceGroup!
    
    var animated = false
    var pagetitle = ""
    var arcs = 0
    var arcOuter = ""
    var arcMiddle = ""
    var arcInner = ""
    var arcOuterVal = 1.0
    var arcOuterMax = 1.0
    var arcMiddleVal = 1.0
    var arcMiddleMax = 1.0
    var arcInnerVal = 1.0
    var arcInnerMax = 1.0
    var units = ""
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        var pageObjects:  [AnyObject] = []
        pageObjects.append([
            "title":"Activity", "arcs":3, "arcOuter":"outer", "arcMiddle":"middle", "arcInner":"inner", "arcOuterVal":312, "arcOuterMax":600, "arcMiddleVal":14, "arcMiddleMax":30, "arcInnerVal":40, "arcInnerMax":100, "units": ""
            ])
        pageObjects.append([
            "title":"Move", "arcs":1, "arcOuter":"outer", "arcMiddle":"middle", "arcInner":"inner", "arcOuterVal":312, "arcOuterMax":600, "arcMiddleVal":50, "arcMiddleMax":100, "arcInnerVal":50, "arcInnerMax":100, "units": "CALS"
            ])
        pageObjects.append([
            "title":"Exercise", "arcs":1, "arcOuter":"green", "arcMiddle":"middle", "arcInner":"inner", "arcOuterVal":14, "arcOuterMax":30, "arcMiddleVal":50, "arcMiddleMax":100, "arcInnerVal":50, "arcInnerMax":100, "units": "MINS"
            ])
        pageObjects.append([
            "title":"Stand", "arcs":1, "arcOuter":"blue", "arcMiddle":"middle", "arcInner":"inner", "arcOuterVal":3, "arcOuterMax":12, "arcMiddleVal":50, "arcMiddleMax":100, "arcInnerVal":50, "arcInnerMax":100, "units": "HRS"
            ])
        
        animated = false
        pagetitle = pageObjects[3].valueForKey("title") as! String
        
        self.setTitle(pagetitle)
        
        arcs = pageObjects[3].valueForKey("arcs") as! Int
        arcOuter = pageObjects[3].valueForKey("arcOuter") as! String
        arcMiddle = pageObjects[3].valueForKey("arcMiddle") as! String
        arcInner = pageObjects[3].valueForKey("arcInner") as! String
        arcOuterVal = pageObjects[3].valueForKey("arcOuterVal") as! Double
        arcOuterMax = pageObjects[3].valueForKey("arcOuterMax") as! Double
        arcMiddleVal = pageObjects[3].valueForKey("arcMiddleVal") as! Double
        arcMiddleMax = pageObjects[3].valueForKey("arcMiddleMax") as! Double
        arcInnerVal = pageObjects[3].valueForKey("arcInnerVal") as! Double
        arcInnerMax = pageObjects[3].valueForKey("arcInnerMax") as! Double
        units = pageObjects[3].valueForKey("units") as! String
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        if(!animated){
            if(arcs == 3){
                arcLabels.setImageNamed("arcLabels")
                outerIcon.setHidden(true)
                outerIconGroup.setHidden(true)
                outerGroup.setBackgroundImageNamed(arcOuter)
                middleGroup.setBackgroundImageNamed(arcMiddle)
                innerGroup.setBackgroundImageNamed(arcInner)
                outerGroup.startAnimatingWithImagesInRange(NSMakeRange(0, Int(arcOuterVal/arcOuterMax*100)+1), duration: duration, repeatCount: 1)
                middleGroup.startAnimatingWithImagesInRange(NSMakeRange(0, Int(arcMiddleVal/arcMiddleMax*100)+1), duration: duration, repeatCount: 1)
                innerGroup.startAnimatingWithImagesInRange(NSMakeRange(0, Int(arcInnerVal/arcInnerMax*100)+1), duration: duration, repeatCount: 1)
                arcLabels.startAnimatingWithImagesInRange(NSMakeRange(0, 22), duration: 1.5, repeatCount: 1)
                animated = true
            } else if (arcs == 2) {
                outerGroup.setBackgroundImageNamed(arcOuter)
                middleGroup.setBackgroundImageNamed("")
                innerGroup.setBackgroundImageNamed(arcInner)
                outerGroup.startAnimatingWithImagesInRange(NSMakeRange(0, Int(arcOuterVal/arcOuterMax*100)+1), duration: duration, repeatCount: 1)
                innerGroup.startAnimatingWithImagesInRange(NSMakeRange(0, Int(arcInnerVal/arcInnerMax*100)+1), duration: duration, repeatCount: 1)
                animated = true
            } else if (arcs == 1) {
                arcLabels.setHidden(true)
                arcLabelsGroup.setHidden(true)
                outerIcon.setImageNamed(pagetitle.lowercaseString+".png")
                outerGroup.setBackgroundImageNamed(arcOuter)
                middleGroup.setBackgroundImageNamed("")
                innerGroup.setBackgroundImageNamed("")
                outerGroup.startAnimatingWithImagesInRange(NSMakeRange(0, Int(arcOuterVal/arcOuterMax*100)+1), duration: duration, repeatCount: 1)
                valLabel.setText(String(format:"%.0f", arcOuterVal))
                ofLabel.setText("OF")
                maxLabel.setText(String(format:"%.0f", arcOuterMax))
                unitLabel.setText(units)
                animated = true
            }
        }
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
